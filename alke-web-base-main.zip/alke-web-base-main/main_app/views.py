from django.shortcuts import render
from django.http import HttpResponse

def home(request):
    return render(request, 'main_app/home.html')

def about(request):
    return render(request, 'main_app/about.html')

def contact(request):
    return render(request, 'main_app/contact.html')

def portfolio(request):
    return render(request, 'main_app/portfolio.html')