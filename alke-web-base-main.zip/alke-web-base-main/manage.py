import os
import sys

if __name__ == '__main__':
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'your_project_name.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError('Could not import Django. Are you sure it\'s installed and available on your PYTHONPATH environment variable?')
        # Adjust the PYTHONPATH if necessary
    execute_from_command_line(sys.argv)